﻿Imports Microsoft.Win32
Public Class Form2
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim keyPath As String = "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\" & OpenFileDialog1.SafeFileName
            Using key As RegistryKey = Registry.LocalMachine.OpenSubKey(keyPath, True)
                If key IsNot Nothing Then
                    key.DeleteValue("Debugger", False)
                Else

                End If
            End Using
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim currentPassword As String = InputBox("Please enter your current password.", "Change Password")
        If currentPassword = My.Settings.Password Then
            Dim newPassword As String = InputBox("Please enter your new password.", "Change Password")
            If newPassword = "" Then
                MsgBox("You must set a password.", MsgBoxStyle.Critical, "Error")
            Else
                MsgBox("Password is changed.", MsgBoxStyle.Information, "Change Password")
                My.Settings.Password = newPassword
                My.Settings.Save()
            End If
        Else
            MsgBox("Current password is incorrect.", MsgBoxStyle.Critical, "Error")
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        MsgBox("Application Blocker 1.3 - Coded By: Emir Alp Koçak using VB.NET" & vbNewLine & "Contact: emiralpkocak@gmail.com", MsgBoxStyle.DefaultButton1, "About")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            'Change
            My.Computer.Network.DownloadFile("https://master.dl.sourceforge.net/project/applicationblocker/Update.txt?viasf=1", My.Computer.FileSystem.SpecialDirectories.Temp & "\version.txt")
            MsgBox("No new version available.", vbInformation, "Update")
            Try
                Kill(My.Computer.FileSystem.SpecialDirectories.Temp & "\version.txt")
            Catch ex As Exception

            End Try
        Catch ex As Exception
            If MsgBox("A new version is available! Would you like to visit the download page?", MsgBoxStyle.YesNo + vbInformation, "Update") = MsgBoxResult.Yes Then
                Dim webPage As String = "https://sourceforge.net/projects/applicationblocker/"
                Process.Start(webPage)
            End If
        End Try
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.AutoCheck = True Then
            CheckBox1.Checked = True
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            My.Settings.AutoCheck = True
            My.Settings.Save()
        Else
            My.Settings.AutoCheck = False
            My.Settings.Save()
        End If
    End Sub
End Class