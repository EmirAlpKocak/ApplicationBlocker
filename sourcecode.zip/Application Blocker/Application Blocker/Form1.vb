﻿Imports Microsoft.Win32
Imports System.Collections.Specialized

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If My.Settings.Password = "" Then
password:
            Dim password As String = InputBox("Please set a password.", "Application Blocker")
            If password = "" Then
                MsgBox("You must set a password.", MsgBoxStyle.Critical, "Error")
                GoTo password
            End If
            My.Settings.Password = password
            My.Settings.Save()
        End If
        Dim currentPassword As String = InputBox("Please enter your password.", "Application Blocker")
        If currentPassword = My.Settings.Password Then
            LoadSavedItems()
            If My.Settings.AutoCheck = True Then
                Try
                    'Change
                    My.Computer.Network.DownloadFile("https://master.dl.sourceforge.net/project/applicationblocker/Update.txt?viasf=1", My.Computer.FileSystem.SpecialDirectories.Temp & "\version.txt")
                    Try
                        Kill(My.Computer.FileSystem.SpecialDirectories.Temp & "\version.txt")
                    Catch ex As Exception

                    End Try
                Catch ex As Exception
                    If MsgBox("A new version is available! Would you like to visit the download page?", MsgBoxStyle.YesNo + vbInformation, "Update") = MsgBoxResult.Yes Then
                        Dim webPage As String = "https://sourceforge.net/projects/applicationblocker/"
                        Process.Start(webPage)
                    End If
                End Try
            End If
        Else
            MsgBox("Password is incorrect.", MsgBoxStyle.Critical, "Error")
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            ListBox1.Items.Add(OpenFileDialog1.SafeFileName)
            Dim keyPath As String = "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\" & OpenFileDialog1.SafeFileName
            Using key As RegistryKey = Registry.LocalMachine.CreateSubKey(keyPath)
                key.SetValue("Debugger", "ntsd -c qd")
            End Using
            SaveItems()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ListBox1.SelectedItems.Count = 0 Then
            MsgBox("Please select an application from the list.", MsgBoxStyle.DefaultButton1, "Unblock Application")
        Else
            Dim keyPath As String = "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\" & ListBox1.SelectedItem.ToString()
            Using key As RegistryKey = Registry.LocalMachine.OpenSubKey(keyPath, True)
                If key IsNot Nothing Then
                    key.DeleteValue("Debugger", False)
                Else

                End If
            End Using
            ListBox1.Items.Remove(ListBox1.SelectedItem)
            SaveItems()
        End If
    End Sub
    Private Sub LoadSavedItems()
        If My.Settings.BlockedApplications IsNot Nothing Then
            For Each item As String In My.Settings.BlockedApplications
                ListBox1.Items.Add(item)
            Next
        End If
    End Sub
    Private Sub SaveItems()
        Dim items As New StringCollection()

        For Each item As String In ListBox1.Items
            items.Add(item)
        Next

        My.Settings.BlockedApplications = items
        My.Settings.Save()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Form2.ShowDialog()
    End Sub
End Class
